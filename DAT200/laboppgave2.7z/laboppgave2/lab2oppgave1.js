
var canvas = document.getElementById("myCanvas");
if(canvas.getContext){
    var ctx = canvas.getContext("2d");
}

ctx.fillStyle = "#EEEE9B"
function draw(){
    resolution = document.getElementById("resolution").value
    kx = document.getElementById("kx").value
    console.log(kx)
    steps = (Math.PI * 2) / resolution
    x_cords = []
    y_cords = []
    x_1_cords = []
    y_1_cords = []

    ctx.clearRect(0,0,canvas.width, canvas.height)
    ctx.fillRect(0, 0, canvas.width, canvas.height)
    i = 0
    while (i < (Math.PI * 2)){
        x = canvas.width / 2 + canvas.width/2 * Math.cos(i)
        y = canvas.height/2 + canvas.height/2 * Math.sin(i)
        x_cords.push(x)
        y_cords.push(y)
        x_1 = canvas.width / 2 + canvas.width/2 * Math.cos(i*kx)
        y_2 = canvas.width / 2 + canvas.width/2 * Math.sin(i*kx)
        x_1_cords.push(x_1)
        y_1_cords.push(y_2)
        i += steps
    }

    drawCords(x_cords, y_cords, x_1_cords, y_1_cords)

    function drawCords(x, y, x_1, y_1){
        ctx.beginPath()
        for (i=0; i < x_cords.length; i++){
            ctx.lineTo(x[i], y[i])
        }
        ctx.closePath()
        ctx.stroke()

        for (i = 0; i < x_1_cords.length; i++){
            console.log(i)
            ctx.moveTo(x[i], y[i])
            ctx.lineTo(x_1[i], y_1[i])
        }
        ctx.stroke()

    }
}

function draw_Squares(){
    resolution = document.getElementById("resolution").value
    division_number = document.getElementById("kx").value;
    p = document.getElementById("p_value").value;
    division_x = canvas.width/division_number;
    division_y = canvas.height/division_number;
    p_1 = [[0, 0]]
    p_2 = [[division_x, 0]]
    p_3 = [[division_x, division_y]]
    p_4 = [[0, division_y]]
    ctx.clearRect(0,0,canvas.width, canvas.height)
    console.log(division_y)
    console.log(division_x)
    for (let i = 0; i <= canvas.height; i+=division_y){
        mod_counter = 0
        for (let j=0; j < canvas.width; j+=division_x) {
            p_1 = [[j,i]]
            p_2 = [[j+division_x,i]]
            p_3 = [[j+division_x, i+division_y]]
            p_4 = [[j, i+division_y]]
            if (mod_counter % 2 === 0){
                draw_spiral(p_1, p_2, p_3, p_4)
            } else {
                draw_spiral(p_4, p_3, p_2, p_1)
            }
            mod_counter += 1
            /*
            p_1 = [[j, i]]
            p_2 = [[j+division_x, i]]
            p_3 = [[j+division_x, i+division_y]]
            p_4 = [[j, i+division_y]]

            */
        }
        //  draw_spiral(p_1, p_2, p_3, p_4)
        }
    }


    function draw_spiral(p_1, p_2, p_3, p_4){
        ctx.beginPath()
        for (i = 0; i < resolution; i++){
            p1_x = (1-p)*p_1[i][0] + p*p_2[i][0]
            p1_y = (1-p)*p_1[i][1] + p*p_2[i][1]
            p2_x = (1-p)*p_2[i][0] + p*p_3[i][0]
            p2_y = (1-p)*p_2[i][1] + p*p_3[i][1]
            p3_x = (1-p)*p_3[i][0] + p*p_4[i][0]
            p3_y = (1-p)*p_3[i][1] + p*p_4[i][1]
            p4_x = (1-p)*p_4[i][0] + p*p_1[i][0]
            p4_y = (1-p)*p_4[i][1] + p*p_1[i][1]
            p_1.push([p1_x, p1_y])
            p_2.push([p2_x, p2_y])
            p_3.push([p3_x, p3_y])
            p_4.push([p4_x, p4_y])
            ctx.lineTo(p_1[i][0],p_1[i][1])
            ctx.lineTo(p_2[i][0],p_2[i][1])
            ctx.lineTo(p_3[i][0],p_3[i][1])
            ctx.lineTo(p_4[i][0],p_4[i][1])
        }
        ctx.stroke()

}

//draw()
draw_Squares()

